<script setup lang="js"></script>

<template>
  <form>
    <slot />
  </form>
</template>
